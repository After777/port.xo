// Initialize the particles
particlesJS.load('particles-js', 'particles.json', function() {
    console.log('particles.js loaded');
});

// Get the hamburger menu and the menu list
const hamburger = document.getElementById('hamburger');
const menu = document.querySelector('.menu');

// Add a click event listener to the hamburger menu
hamburger.addEventListener('click', function() {
    // Toggle the menu list
    menu.classList.toggle('show');
});
